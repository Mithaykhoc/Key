class AudioManager {
    constructor() {
        this.synth = new Tone.Synth().toDestination();
        this.initialized = false;
    }

    async init() {
        if (!this.initialized) {
            await Tone.start();
            this.initialized = true;
        }
    }

    playSpinSound() {
        this.synth.triggerAttackRelease("C4", "8n");
    }

    playWinSound() {
        const notes = ["C4", "E4", "G4"];
        notes.forEach((note, i) => {
            setTimeout(() => {
                this.synth.triggerAttackRelease(note, "8n");
            }, i * 100);
        });
    }

    playLoseSound() {
        this.synth.triggerAttackRelease("A3", "4n");
    }
}

const audioManager = new AudioManager();
