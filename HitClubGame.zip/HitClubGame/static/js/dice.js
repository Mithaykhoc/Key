// Thêm comment giải thích vào phần đầu file
class DiceGame {
    constructor() {
        this.canvas = document.getElementById('diceCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.diceCount = 3;
        this.diceSize = 60;
        this.rolling = false;
        this.diceValues = Array(this.diceCount).fill(1);
        this.selectedBet = null;
        this.betAmount = 10;

        // Danh sách tổng điểm mong muốn - có thể thêm/sửa các số từ 3-18
        // Ví dụ: [8, 12, 13, 14, 16, 18] hoặc bất kỳ dãy số nào
        this.predefinedSums = [12, 18, 7, 10, 11, 13, 9, 3, 5, 16, 9, 6, 11, 11, 11, 8 ,13, 3, 18, 5, 11, 12, 4, 6, 17, 11, 6];
        this.resultIndex = 0; // Chỉ số để lấy số tiếp theo trong mảng

        this.initializeCanvas();
        this.setupEventListeners();
        this.draw();
    }

    initializeCanvas() {
        this.canvas.width = Math.min(window.innerWidth - 40, 800);
        this.canvas.height = 200;
        this.diceSize = Math.min(60, this.canvas.width / 5);
    }

    setupEventListeners() {
        window.addEventListener('resize', () => {
            this.initializeCanvas();
            this.draw();
        });

        const taiBtn = document.getElementById('taiBtn');
        const xiuBtn = document.getElementById('xiuBtn');
        const rollBtn = document.getElementById('rollDice');
        const decreaseBetBtn = document.getElementById('decreaseDiceBet');
        const increaseBetBtn = document.getElementById('increaseDiceBet');

        if (taiBtn) taiBtn.addEventListener('click', () => this.selectBet('tai'));
        if (xiuBtn) xiuBtn.addEventListener('click', () => this.selectBet('xiu'));
        if (rollBtn) rollBtn.addEventListener('click', () => this.roll());
        if (decreaseBetBtn) decreaseBetBtn.addEventListener('click', () => this.adjustBet(-10));
        if (increaseBetBtn) increaseBetBtn.addEventListener('click', () => this.adjustBet(10));
    }

    selectBet(type) {
        if (this.rolling) return;
        this.selectedBet = type;
        document.getElementById('taiBtn').classList.toggle('selected', type === 'tai');
        document.getElementById('xiuBtn').classList.toggle('selected', type === 'xiu');
    }

    adjustBet(amount) {
        if (this.rolling) return;
        const newBet = this.betAmount + amount;
        const credits = parseInt(document.getElementById('credits').textContent);
        if (newBet >= 10 && newBet <= 100 && newBet <= credits) {
            this.betAmount = newBet;
            document.getElementById('diceBet').textContent = this.betAmount;
        }
    }

    // Tạo bộ số có tổng bằng targetSum
    generateDiceValues(targetSum) {
        // Kiểm tra giới hạn của tổng (3 xúc xắc: min=3, max=18)
        if (targetSum < 3 || targetSum > 18) return [1, 1, 1];

        let dice = [1, 1, 1];
        let currentSum;

        do {
            // Reset về giá trị ban đầu (mỗi xúc xắc = 1)
            dice = [1, 1, 1];
            currentSum = 3;

            // Tăng dần giá trị các xúc xắc cho đến khi đạt được tổng mong muốn
            while (currentSum < targetSum) {
                // Chọn ngẫu nhiên 1 trong 3 xúc xắc để tăng giá trị
                const diceIndex = Math.floor(Math.random() * 3);
                // Chỉ tăng nếu mặt xúc xắc chưa đạt max (6)
                if (dice[diceIndex] < 6) {
                    dice[diceIndex]++;
                    currentSum++;
                }
            }
        } while (currentSum !== targetSum);

        return dice;
    }

    async roll() {
        if (this.rolling || !this.selectedBet) return;

        const credits = parseInt(document.getElementById('credits').textContent);
        if (credits < this.betAmount) return;

        await audioManager.init();
        this.rolling = true;

        // Trừ tiền cược
        const newCredits = credits - this.betAmount;
        document.getElementById('credits').textContent = newCredits;
        document.getElementById('diceMessage').textContent = '';

        audioManager.playSpinSound();

        // Lấy tổng điểm mong muốn từ danh sách
        const targetSum = this.predefinedSums[this.resultIndex];
        // Tăng chỉ số cho lần sau
        this.resultIndex = (this.resultIndex + 1) % this.predefinedSums.length;

        const rollDuration = 2000;
        const startTime = Date.now();
        const finalDiceValues = this.generateDiceValues(targetSum);

        const animate = () => {
            const currentTime = Date.now() - startTime;
            const progress = Math.min(currentTime / rollDuration, 1);

            if (progress < 1) {
                // Hiệu ứng quay ngẫu nhiên
                this.diceValues = this.diceValues.map(() =>
                    Math.floor(Math.random() * 6) + 1
                );
                requestAnimationFrame(animate);
            } else {
                // Kết quả cuối cùng theo targetSum
                this.diceValues = finalDiceValues;
                this.rolling = false;
                this.checkResult();
            }
            this.draw();
        };

        animate();
    }

    checkResult() {
        const sum = this.diceValues.reduce((a, b) => a + b, 0);
        const isTai = sum > 10;
        const message = document.getElementById('diceMessage');
        const creditsElement = document.getElementById('credits');
        const currentCredits = parseInt(creditsElement.textContent);

        // Hiển thị kết quả
        message.textContent = `Tổng: ${sum} - ${isTai ? 'TÀI' : 'XỈU'}`;

        // Kiểm tra thắng thua
        const playerWon = (isTai && this.selectedBet === 'tai') || (!isTai && this.selectedBet === 'xiu');

        if (playerWon) {
            const winAmount = this.betAmount * 2;
            const newCredits = currentCredits + winAmount;
            creditsElement.textContent = newCredits;
            message.textContent += ` - Thắng +${winAmount}!`;
            audioManager.playWinSound();
        } else {
            message.textContent += ' - Thua!';
            audioManager.playLoseSound();
        }

        // Cập nhật điểm cao
        const highScore = Math.max(
            currentCredits + (playerWon ? this.betAmount * 2 : 0),
            parseInt(localStorage.getItem('highScore') || 0)
        );
        localStorage.setItem('highScore', highScore.toString());
    }

    drawDice(x, y, value) {
        const size = this.diceSize;
        const dotRadius = size / 10;

        // Vẽ khung xúc xắc
        this.ctx.fillStyle = '#fff';
        this.ctx.fillRect(x, y, size, size);
        this.ctx.strokeStyle = '#000';
        this.ctx.strokeRect(x, y, size, size);

        // Vị trí các chấm cho mỗi mặt xúc xắc
        const dotPositions = {
            1: [[0.5, 0.5]],
            2: [[0.25, 0.25], [0.75, 0.75]],
            3: [[0.25, 0.25], [0.5, 0.5], [0.75, 0.75]],
            4: [[0.25, 0.25], [0.75, 0.25], [0.25, 0.75], [0.75, 0.75]],
            5: [[0.25, 0.25], [0.75, 0.25], [0.5, 0.5], [0.25, 0.75], [0.75, 0.75]],
            6: [[0.25, 0.25], [0.75, 0.25], [0.25, 0.5], [0.75, 0.5], [0.25, 0.75], [0.75, 0.75]]
        };

        // Vẽ các chấm
        this.ctx.fillStyle = '#000';
        const dots = dotPositions[value] || [];
        dots.forEach(([dx, dy]) => {
            this.ctx.beginPath();
            this.ctx.arc(
                x + dx * size,
                y + dy * size,
                dotRadius,
                0,
                Math.PI * 2
            );
            this.ctx.fill();
        });
    }

    draw() {
        if (!this.ctx) return;

        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        // Vẽ nền
        this.ctx.fillStyle = '#1a1a1a';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Tính toán vị trí các xúc xắc
        const totalWidth = this.diceCount * this.diceSize + (this.diceCount - 1) * 20;
        let x = (this.canvas.width - totalWidth) / 2;
        const y = (this.canvas.height - this.diceSize) / 2;

        // Vẽ từng xúc xắc
        this.diceValues.forEach((value) => {
            this.drawDice(x, y, value);
            x += this.diceSize + 20;
        });
    }
}

// Khởi tạo game khi trang tải xong
window.addEventListener('load', () => {
    const diceGame = new DiceGame();
});