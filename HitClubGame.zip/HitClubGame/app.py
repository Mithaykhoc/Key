import os
from flask import Flask, render_template, jsonify
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/score', methods=['POST'])
def save_score():
    # Simple score saving endpoint
    return jsonify({'status': 'success'})
